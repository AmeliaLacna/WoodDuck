Project name: Wood Ducks (WD)
Description of the Project:
What the project is about

Data Collection: Surveyed Nests
Description of the data:
What the data is about

Methods for data collection are describe in the DMP.

Abbreviations

File Name Convention:
Project_Name_Individual ID 

Folder Structure

├───WoodDucks
│   ├───Code
│   ├───Data
│   │   ├───Analysed
│   │   ├───Processed
│   │   └───Raw
│   └───Literature
|--CHANGELOG.txt
|README.txt 